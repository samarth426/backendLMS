/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from "fs";
import path from "path";

// Define strict types for the database entities
export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  branch: string; // Electrical, Mechanical, Civil, Electronics, EC, Computer
  track: string; // Fresher, Experienced, Manager
  isPremiumUnlocked: boolean; // Managed via Stripe webhooks
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
}

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  videoUrl?: string; // Mock video identification
  quiz?: QuizQuestion[];
}

export interface Module {
  id: string;
  title: string;
  lessons: Lesson[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  branch: string; // Electrical, Mechanical, Civil, Electronics, EC, Computer, Process Excellence
  duration: string; // "6 Months" or "1 Year" or Belt-specific duration
  type: "PG Certificate" | "Advanced Diploma" | "Certification";
  modules: Module[];
}

export interface UserProgress {
  id: string;
  userId: string;
  courseId: string;
  lessonId: string;
  completed: boolean;
  score?: number; // Score obtained on lesson quiz
  watchPercent: number; // 0 to 100
  updatedAt: string;
}

export interface DatabaseSchema {
  users: User[];
  courses: Course[];
  progress: UserProgress[];
}

const DATA_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

/**
 * Robust JSON Database manager using standard Node filesystem calls to ensure complete sync persistence.
 */
class LocalDB {
  private schema: DatabaseSchema = {
    users: [],
    courses: [],
    progress: [],
  };

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const rawContent = fs.readFileSync(DB_FILE, "utf-8");
        this.schema = JSON.parse(rawContent);
      } else {
        // Hydrate database with default courses to match the curriculum requirement exactly
        this.schema.courses = this.generateDefaultCourses();
        this.save();
      }
    } catch (err) {
      console.error("LocalDB initialization error, fallback to in-memory:", err);
    }
  }

  private save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.schema, null, 2), "utf-8");
    } catch (err) {
      console.error("Failed to commit write to db.json file:", err);
    }
  }

  // Generic Entity Retrieval Methods
  public getUsers(): User[] {
    return this.schema.users;
  }

  public saveUsers(users: User[]): void {
    this.schema.users = users;
    this.save();
  }

  public getCourses(): Course[] {
    return this.schema.courses;
  }

  public getProgress(): UserProgress[] {
    return this.schema.progress;
  }

  public saveProgress(progress: UserProgress[]): void {
    this.schema.progress = progress;
    this.save();
  }

  /**
   * Automatically generate the official Sixsigma AI Curriculum courses structure to ensure
   * students have a real set of free and premium courses to interact with based on standard engineering branches.
   */
  private generateDefaultCourses(): Course[] {
    return [
      // ELECTRICAL
      {
        id: "ee-6m-pgcert",
        title: "PG Certificate in Smart Grid & Power Systems",
        description: "Explore renewable energy integration, smart gird automation controls, and PLC/SCADA simulation techniques.",
        branch: "Electrical",
        duration: "6 Months",
        type: "PG Certificate",
        modules: [
          {
            id: "ee-6m-m1",
            title: "Smart Grid & Power Infrastructure",
            lessons: [
              {
                id: "ee-6m-l1",
                title: "Grid Optimization and Load Alignment",
                duration: "25 min",
                videoUrl: "smart_grid_optimization",
                quiz: [
                  {
                    id: "ee-q1",
                    question: "Which of the following is an essential component of a Smart Grid energy balance system?",
                    options: ["Traditional analog relays", "Phasor Measurement Units (PMUs)", "Copper wire insulators", "Mechanical load balancers"],
                    correctOptionIndex: 1
                  }
                ]
              },
              {
                id: "ee-6m-l2",
                title: "Industrial PLC & SCADA Controls Integration",
                duration: "30 min",
                videoUrl: "scada_control",
                quiz: [
                  {
                    id: "ee-q2",
                    question: "What is the primary function of a SCADA system in smart infrastructure?",
                    options: ["Direct analog cable switching", "Supervisory control and real-time telemetry", "Creating physical blueprints", "Generating high voltages"],
                    correctOptionIndex: 1
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        id: "ee-1y-diploma",
        title: "Advanced Professional Diploma in EV Systems & Battery Technology",
        description: "Premium level system modeling including Battery Management System (BMS) modeling, thermal modeling, and EV drivetrains.",
        branch: "Electrical",
        duration: "1 Year",
        type: "Advanced Diploma",
        modules: [
          {
            id: "ee-1y-m1",
            title: "EV Drivetrains & Power Electronics",
            lessons: [
              {
                id: "ee-1y-l1",
                title: "BMS Cell Balancing Algorithms",
                duration: "40 min",
                videoUrl: "bms_balancing",
                quiz: [
                  {
                    id: "ee-1y-q1",
                    question: "Why is passive cell balancing preferred in low-cost BMS implementations?",
                    options: ["It pumps energy back into weaker cells", "It dissipates excess energy in heat-sink resistors", "It avoids battery degradation entirely", "It raises cell impedance actively"],
                    correctOptionIndex: 1
                  }
                ]
              }
            ]
          }
        ]
      },

      // MECHANICAL
      {
        id: "me-6m-pgcert",
        title: "PG Certificate in Product Diagnostics & CAD Design",
        description: "Comprehensive SolidWorks/CATIA modeling combined with structural simulation techniques and condition monitoring basics.",
        branch: "Mechanical",
        duration: "6 Months",
        type: "PG Certificate",
        modules: [
          {
            id: "me-6m-m1",
            title: "CAD/CAM Simulation Essentials",
            lessons: [
              {
                id: "me-6m-l1",
                title: "Structural FEA (Finite Element Analysis) Boundary Conditions",
                duration: "20 min",
                videoUrl: "fea_essentials",
                quiz: [
                  {
                    id: "me-q1",
                    question: "What is the primary objective of defining constraints in basic FEA simulation?",
                    options: ["Increasing model mesh size", "Preventing rigid body rotation/translation", "Selecting material elasticity", "Accelerating CAD render speed"],
                    correctOptionIndex: 1
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        id: "me-1y-diploma",
        title: "Advanced Professional Diploma in Digital Twin & Robotic Integration",
        description: "Advanced simulation utilizing Siemens NX, manufacturing digitalization, and Industry 4.0 predictive diagnostics.",
        branch: "Mechanical",
        duration: "1 Year",
        type: "Advanced Diploma",
        modules: [
          {
            id: "me-1y-m1",
            title: "Robotic Cobots and Industry 4.0 Layouts",
            lessons: [
              {
                id: "me-1y-l1",
                title: "Kinematic Digital Twin Calibration",
                duration: "45 min",
                videoUrl: "kinematic_twin",
                quiz: [
                  {
                    id: "me-1y-q1",
                    question: "What distinguishes a Robotic Cobot from a traditional industrial robot?",
                    options: ["It lacks an electric power unit", "It operates alongside humans without physical safety cages", "It requires offline manual programming only", "It can only handle hydraulic loads"],
                    correctOptionIndex: 1
                  }
                ]
              }
            ]
          }
        ]
      },

      // CIVIL
      {
        id: "ce-6m-pgcert",
        title: "PG Certificate in Structural Analysis & LEED",
        description: "Structural modeling inside STAAD.Pro combined with sustainability systems under modern LEED green standards.",
        branch: "Civil",
        duration: "6 Months",
        type: "PG Certificate",
        modules: [
          {
            id: "ce-6m-m1",
            title: "Structural Design Fundamentals",
            lessons: [
              {
                id: "ce-6m-l1",
                title: "Static Load Estimation and Structural Failures",
                duration: "30 min",
                videoUrl: "static_strains",
                quiz: [
                  {
                    id: "ce-q1",
                    question: "Which code governs standard static steel strain margins in modern concrete reinforcements?",
                    options: ["ISO 14001", "IS 456 / ACI-318", "ASTM D451", "IEEE 802.11"],
                    correctOptionIndex: 1
                  }
                ]
              }
            ]
          }
        ]
      },

      // PROCESS EXCELLENCE (All Levels)
      {
        id: "pe-six-sigma-green",
        title: "Lean Six Sigma Green Belt (Practitioner Course)",
        description: "Standard DMAIC methodology, statistical process control, and measurement system analyses with real software models.",
        branch: "Process Excellence",
        duration: "4 Weeks",
        type: "Certification",
        modules: [
          {
            id: "pe-ssg-m1",
            title: "DMAIC - Define, Measure & Analyse",
            lessons: [
              {
                id: "pe-ssg-l1",
                title: "Process Capability Index (Cp & Cpk)",
                duration: "35 min",
                videoUrl: "process_capability",
                quiz: [
                  {
                    id: "pe-ss-q1",
                    question: "An operations process is considered minimally capable under Six Sigma standards if the Cpk score reaches:",
                    options: ["1.0", "1.33", "2.0", "0.5"],
                    correctOptionIndex: 1
                  }
                ]
              }
            ]
          }
        ]
      }
    ];
  }
}

export const dbInstance = new LocalDB();
