/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Network, 
  Settings, 
  Layers, 
  Tv, 
  Cpu, 
  HelpCircle, 
  BookOpen, 
  TrendingUp, 
  Briefcase, 
  Gauge, 
  Terminal, 
  Database,
  Shuffle,
  ShieldAlert,
  ArrowRight
} from "lucide-react";

interface SyllabusCatalogProps {
  onSignupRequested: (branch: string, track: string) => void;
  isLoggedIn: boolean;
}

export default function SitemapCatalog({ onSignupRequested, isLoggedIn }: SyllabusCatalogProps) {
  const [selectedBranch, setSelectedBranch] = useState<string>("Electrical");
  const [activeTab, setActiveTab] = useState<"certificate" | "diploma">("certificate");

  // Branches Content Static Data mapping perfectly to the curriculum document!
  const branchData: Record<string, any> = {
    Electrical: {
      tag: "Power Systems & BMS Systems",
      icon: Network,
      color: "from-[#ef4444] to-[#f97316]",
      certificate: {
        title: "PG Certificate in Smart Grid & Power Systems (6 Months)",
        audience: "BE/B.Tech EE — Freshers & Early-Career (0–5 yrs)",
        courses: [
          "Power Systems & Smart Grid Fundamentals",
          "Electrical Machines & Drives (AI-Diagnostics)",
          "PLC, SCADA & Industrial Automation",
          "Power Electronics & Inverter Design",
          "Energy Management, Audit & ISO 50001",
          "Python for Electrical Engineers",
          "MATLAB / Simulink for Power Systems"
        ],
        outcomes: "Accelerated job drives, resume optimizations, and solid high-voltage foundational understanding.",
        fees: "₹45,000  │  Monthly EMIs starting ₹4,500"
      },
      diploma: {
        title: "Advanced Professional Diploma in EV Systems & Battery Tech (1 Year)",
        audience: "All Levels (Freshers to Managers/Team Leads)",
        specializations: {
          fresher: "General Foundations → Systems Calibration → Final Placement Acceleration",
          experienced: "High Voltage Design + Embedded BMS firmware + Tech Leadership",
          manager: "Renewable Portfolios, Energy Risk Analytics, Capital Budget Allocations / ROI"
        },
        courses: [
          "Advanced Power Systems & Renewable Grid Integration",
          "EV Technology & Battery Management Systems (BMS)",
          "AI/ML for Predictive Maintenance in Grid Assets",
          "IoT-Based Smart Building & Grid Energy Automation",
          "High Voltage Engineering & System Electrical Safety",
          "Digital Twin for Networks (ETAP / DIgSILENT)",
          "Lean Six Sigma & Continuous improvement for Manufacturing"
        ],
        tools: ["MATLAB/Simulink", "ETAP", "DIgSILENT", "AutoCAD Electrical", "Python", "SAP PM"],
        sectors: "Power Utilities, EV Giga-plants, OEMs, Smart Buildings, Aero-Defense",
        fees: "₹95,000  │  Corporate Sponsors / No-Cost EMIs"
      }
    },
    Mechanical: {
      tag: "Advanced Mechanics & Digital Twin",
      icon: Settings,
      color: "from-[#3b82f6] to-[#06b6d4]",
      certificate: {
        title: "PG Certificate in CAD Design & Product Engineering (6 Months)",
        audience: "BE/B.Tech ME — Freshers (0-2 yrs) & Early-Career",
        courses: [
          "CAD/CAM, Generative Solid Modeling (SolidWorks/CATIA)",
          "Manufacturing Processes & Quality Systems (SPC, FMEA)",
          "Thermodynamics & Industrial Fluid Dynamics",
          "Industrial IoT & Mechanical Condition Monitoring",
          "Six Sigma Green Belt Foundations (DMAIC Core)",
          "Finite Element Analysis (FEA) Basics using ANSYS"
        ],
        outcomes: "Design firm placements, drafting expertise, and automated machine diagnostics.",
        fees: "₹45,000  │  EMIs starting at ₹4,500"
      },
      diploma: {
        title: "Advanced Professional Diploma in Digital Twin & Robotic Integration (1 Year)",
        audience: "All Levels (Freshers to Production Managers)",
        specializations: {
          fresher: "Vibration Controls & Kinematic CAD Design → 1-on-1 Portfolio review",
          experienced: "Thermal Stress Optimization + Robotic Cobot programing + Lean Black Belt",
          manager: "Enterprise Supply Chains, Plant Logistics, Agile Industry 4.0 migrations"
        },
        courses: [
          "Advanced CAD Manufacturing & Industry 4.0 Integration",
          "AI Models for Predictive Maintenance & Automated QA Systems",
          "Robotics & Collaborative Robot Workstations (Cobots)",
          "Dynamic Digital Twin & Physics Simulators (ANSYS/NX)",
          "Lean Six Sigma Black Belt (DOE, Lean Six Sigma)",
          "Global Supply Chain and Inventory Flow Optimizer",
          "Additive Manufacturing / Industrial 3D Printing Systems"
        ],
        tools: ["SolidWorks", "CATIA", "ANSYS", "Siemens NX", "Python", "SAP PP", "Minitab"],
        sectors: "Automotive, Aerospace, FMCG Shopfloors, Heavy Power-Turbines, Defense",
        fees: "₹95,000  │  Scholarships available"
      }
    },
    Civil: {
      tag: "Structural Design & BIM Management",
      icon: Layers,
      color: "from-[#10b981] to-[#059669]",
      certificate: {
        title: "PG Certificate in Structural Analysis & Estimations (6 Months)",
        audience: "BE/B.Tech CE — Civil Graduates & Infrastructure Engineers",
        courses: [
          "Structural Analysis & Seismic Calculations (STAAD.Pro)",
          "AutoCAD & Architectural Revit Modeling",
          "Construction Project Scheduling (CPM, PERT)",
          "Geotechnical Engineering & Deep Excavation Foundation Design",
          "Quantity Surveying & Professional Estimations (Excel/Python)"
        ],
        outcomes: "Design Engineer positions, site supervisor certifications.",
        fees: "₹45,000"
      },
      diploma: {
        title: "Advanced Professional Diploma in BIM & Smart Infrastructure (1 Year)",
        audience: "Graduates, Surveyors, and Senior Civil Leads",
        specializations: {
          fresher: "Structural Basics → Revit Building Modeling → Technical Mock Sprints",
          experienced: "Earthquake Load Vectors + Advanced BIM coordination + Contract Arbitrations",
          manager: "L&D Project Budgeting, FIDIC Tender reviews, Capital Expenditure Strategy"
        },
        courses: [
          "Integrated BIM — Revit Architecture + Navisworks Coordination",
          "Autonomous Drone Mapping & Automated Site Surveying",
          "Smart City Sensors & IoT Structural Deflection Monitoring",
          "Modern Earthquake Resilience & Prestressed Concrete",
          "Contract Administration, FIDIC Clauses & Civil Arbitration",
          "Sustainable Infrastructure & Leed/Griha Rating Metrics",
          "Industrial Project Management (PMP Framework & Primavera)"
        ],
        tools: ["STAAD.Pro", "ETABS", "AutoCAD", "Revit", "Navisworks", "MS Project", "Primavera P6"],
        sectors: "Real Estate Developers, Smart City Infrastructure, Giga Tenders, Urban Planning",
        fees: "₹95,000"
      }
    },
    Electronics: {
      tag: "Embedded Firmware & TinyML",
      icon: Tv,
      color: "from-[#a855f7] to-[#ec4899]",
      certificate: {
        title: "PG Certificate in Embedded Systems & PCB Layout (6 Months)",
        audience: "BE/B.Tech EE/ECE — Hardware prototypers",
        courses: [
          "Embedded Systems on ARM Cortex microcontrollers",
          "PCB Layout & High-Speed Circuit design (Altium/KiCad)",
          "Hardware Verification Languages (Verilog/VHDL)",
          "High Performance Digital Signal Processing (DSP)",
          "IoT Physical Prototype modeling & Arduino/Pi design",
          "Python Hardware API Interface development"
        ],
        outcomes: "PCB Layout Architect positions, Hardware Integration jobs.",
        fees: "₹45,000"
      },
      diploma: {
        title: "Advanced Professional Diploma in Embedded Systems & TinyML (1 Year)",
        audience: "All Hardware & Hardware-Firmware Engineers",
        specializations: {
          fresher: "C Firmware basics → PCB modeling → Hardware validation lab",
          experienced: "Edge-AI Model pruning + RTOS Core Kernel modification + TinyML compiler optimization",
          manager: "Hardware Product Lifecycle, Go-To-Market compliance specs, Global Chip Supply Chain"
        },
        courses: [
          "Complex Embedded Firmware with Real-Time OS (RTOS)",
          "AI at the Edge — TinyML & Edge AI Deployment Analytics",
          "High-Density PCB Optimization & Signal Integrity Analysis",
          "VLSI & Semiconductor Verification pipelines ( Vivado )",
          "Next-Gen Smart Sensor Web Systems & Mesh networking",
          "Modern Electronics Quality Assurance (AEC-Q & IPC Standard Specs)",
          "System Digital Twin for Advanced Electronics networks"
        ],
        tools: ["Altium", "KiCad", "MATLAB", "Arduino", "Raspberry Pi", "ModelSim", "Xilinx Vivado"],
        sectors: "Consumer Electronics, ADAS Automotive, Medical Diagnostic Devices, Semiconductor R&D",
        fees: "₹95,000"
      }
    },
    Computer: {
      tag: "AI Engineering & Systems Architecture",
      icon: Cpu,
      color: "from-[#ec4899] to-[#f43f5e]",
      certificate: {
        title: "PG Certificate in Cloud & AI Development (6 Months)",
        audience: "BE/B.Tech CS/IT — Software developers",
        courses: [
          "Full Stack Web Systems (React.js + Express.js + NoSQL)",
          "Foundational Machine Learning models & Python Data Prep",
          "Cloud Infrastructure deployment (Amazon AWS / Google GCP)",
          "Continuous Delivery Pipelines (CI/CD / Docker Systems)",
          "Database Management (Structured SQL + Document NoSQL)",
          "Secure Software development & Cryptography fundamentals"
        ],
        outcomes: "Software Engineer positions, Full Stack Developer, Cloud Associate.",
        fees: "₹45,000"
      },
      diploma: {
        title: "Advanced Professional Diploma in Agentic AI & Systems Architecture (1 Year)",
        audience: "Engineers, Architects, Tech Leads, and managers",
        specializations: {
          fresher: "Git Core, Data Structures, Algorithms → Active Placement Sprint",
          experienced: "Deep learning model tuning + Enterprise System Design + Big Data stream pipelines",
          manager: "Product Roadmapping, Engineering Budget trackers, SOC/ISO Compliance strategies"
        },
        courses: [
          "Advanced Deep Learning & Natural Language Orchestrators",
          "Enterprise System Design & High-Scalability Architectures",
          "Automated Agentic AI Orchestrations & Tool Use systems",
          "Big Data Engineering (Apache Spark, Kafka Streams)",
          "Enterprise MLOps & Production Model Monitoring",
          "Cryptographic Blockchain protocols & Decentralized Ledger APIs",
          "Technology Project leadership & Scaled Agile (SAFe) models"
        ],
        tools: ["Python", "TensorFlow/PyTorch", "React", "Node.js", "Docker & Kubernetes", "AWS", "Apache Spark"],
        sectors: "IT, FAANG Consultancies, High-Frequency Fintech, Healthcare Tech, SAAS operations",
        fees: "₹95,000"
      }
    }
  };

  const SelectedIcon = branchData[selectedBranch]?.icon || Network;

  return (
    <div className="space-y-12 pb-16">
      {/* SECTION 1: Outcomes Hero Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1e293b] via-[#1e293b]/90 to-[#020617] border border-[#334155] p-8 md:p-12 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#38bdf8]/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#4f46e5]/5 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-[#38bdf8]/30 bg-[#38bdf8]/10 text-xs font-mono text-[#38bdf8]">
            <Gauge className="h-3.5 w-3.5" />
            Empowering Careers Pan-India & Globally
          </div>
          
          <h2 className="text-4xl md:text-5xl font-extrabold text-white leading-tight tracking-tight">
            Become an Industry-Ready Engineer — <span className="bg-gradient-to-r from-[#38bdf8] to-[#818cf8] bg-clip-text text-transparent">PG Programmes for All Branches</span>
          </h2>
          
          <p className="text-sm md:text-base text-[#94a3b8] leading-relaxed max-w-2xl">
            We bridge the gap between heavy academic engineering and modern digital workflows. Selected from the world's most detailed curricula, our PG Certificate and Advanced Diplomas integrate <strong>Process Excellence</strong> with functional branch software.
          </p>

          {/* Core Program Overview - Bento Grid Substructure */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
            <div className="p-5 bg-[#0f172a]/60 rounded-2xl border border-[#334155]/60 hover:border-[#38bdf8] transition-all">
              <h4 className="text-[#94a3b8] text-[10px] font-bold uppercase tracking-wider font-mono">Placement Metric</h4>
              <p className="text-2xl font-black text-white mt-1">85%+ Placement</p>
              <p className="text-[11px] text-[#10b981] font-sans font-medium mt-1">✓ Guaranteed support inside 6 months</p>
            </div>
            <div className="p-5 bg-[#0f172a]/60 rounded-2xl border border-[#334155]/60 hover:border-[#38bdf8] transition-all">
              <h4 className="text-[#94a3b8] text-[10px] font-bold uppercase tracking-wider font-mono">Average CTC</h4>
              <p className="text-2xl font-black text-white mt-1">₹3.5L – ₹25 LPA</p>
              <p className="text-[11px] text-[#fbbf24] font-sans font-medium mt-1">★ Across 200+ global partners</p>
            </div>
            <div className="p-5 bg-[#0f172a]/60 rounded-2xl border border-[#334155]/60 hover:border-[#38bdf8] transition-all">
              <h4 className="text-[#94a3b8] text-[10px] font-bold uppercase tracking-wider font-mono">Certifications</h4>
              <p className="text-2xl font-black text-white mt-1">Sixsigma Verified</p>
              <p className="text-[11px] text-[#818cf8] font-sans font-medium mt-1">⚙ ISO 50001 & Lean Belt aligned</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: Dynamic Branch Explorer Section */}
      <section className="space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-4">
          <div>
            <h3 className="text-xl md:text-2xl font-extrabold text-white tracking-tight">Dynamic Branch Program Explorer</h3>
            <p className="text-xs text-[#94a3b8] font-mono mt-1">Select your engineering domain below to evaluate syllabus criteria, target roles, tools, and pricing</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {Object.keys(branchData).map((branchName) => (
              <button
                key={branchName}
                onClick={() => setSelectedBranch(branchName)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono border transition-all ${
                  selectedBranch === branchName
                    ? "bg-[#0ea5e9] text-white border-[#38bdf8] shadow-lg shadow-[#0ea5e9]/20"
                    : "bg-[#1e293b] text-[#94a3b8] border-[#334155] hover:text-white"
                }`}
              >
                {branchName}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Branch Portal Display */}
        {branchData[selectedBranch] && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-[#1e293b] border border-[#334155] rounded-2xl p-6 relative overflow-hidden shadow-xl">
            
            {/* Left Wing Sidebar */}
            <div className="lg:col-span-4 space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-r from-[#0f172a] to-[#1e293b] border border-[#334155]/50 shadow-inner">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-lg bg-gradient-to-r ${branchData[selectedBranch].color}`}>
                    <SelectedIcon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white leading-tight">{selectedBranch}</h4>
                    <p className="text-[10px] text-[#fbbf24] font-mono tracking-wide uppercase font-bold">{branchData[selectedBranch].tag}</p>
                  </div>
                </div>
              </div>

              {/* Dynamic Tabs trigger */}
              <div className="bg-[#0f172a] p-1 rounded-xl border border-[#334155] flex">
                <button
                  onMouseEnter={() => setActiveTab("certificate")}
                  onClick={() => setActiveTab("certificate")}
                  className={`flex-1 text-center py-2 rounded-lg text-xs font-bold font-mono cursor-pointer transition-all ${
                    activeTab === "certificate"
                      ? "bg-[#1e293b] text-[#38bdf8] border border-[#334155]"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  6M Certif.
                </button>
                <button
                  onMouseEnter={() => setActiveTab("diploma")}
                  onClick={() => setActiveTab("diploma")}
                  className={`flex-1 text-center py-2 rounded-lg text-xs font-bold font-mono cursor-pointer transition-all ${
                    activeTab === "diploma"
                      ? "bg-[#1e293b] text-[#38bdf8] border border-[#334155]"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  1Yr Diploma
                </button>
              </div>

              {/* Target sectors and skills */}
              <div className="p-4 bg-[#0f172a] rounded-xl border border-[#334155] space-y-3">
                <h5 className="text-[#94a3b8] text-xs font-semibold font-mono tracking-wider uppercase">Target Industries</h5>
                <p className="text-xs text-white leading-relaxed">
                  {activeTab === "certificate" ? "Design offices, CAD setups, standard public networks." : branchData[selectedBranch].diploma.sectors}
                </p>
                
                {branchData[selectedBranch].diploma.tools && (
                  <>
                    <h5 className="text-[#94a3b8] text-xs font-semibold font-mono tracking-wider uppercase pt-2">Tools & Technologies</h5>
                    <div className="flex flex-wrap gap-1">
                      {branchData[selectedBranch].diploma.tools.map((tool: string) => (
                        <span key={tool} className="text-[10px] bg-[#1e293b] text-[#38bdf8] font-mono px-2 py-0.5 rounded border border-[#334155]">
                          {tool}
                        </span>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* Instant Enrollment Trigger */}
              <div className="bg-[#1e1b4b]/60 border border-[#4338ca]/40 p-4 rounded-xl">
                <h5 className="text-xs font-bold text-[#818cf8] font-mono">Ready to Enroll?</h5>
                <p className="text-[11px] text-[#cbd5e1] mt-1 leading-relaxed">Access real-time code simulation classrooms, structured assessments, and professional placement networks.</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <button
                    onClick={() => onSignupRequested(selectedBranch, "Fresher")}
                    className="flex-1 bg-[#0ea5e9] hover:bg-[#0284c7] text-white text-xs font-bold py-1.5 px-3 rounded-lg transition-all font-mono"
                  >
                    🎓 Fresher
                  </button>
                  <button
                    onClick={() => onSignupRequested(selectedBranch, "Experienced")}
                    className="flex-1 bg-[#1e293b] hover:bg-[#334155] text-white text-xs border border-[#334155] font-bold py-1.5 px-3 rounded-lg transition-all font-mono"
                  >
                    💼 Pro
                  </button>
                </div>
              </div>
            </div>

            {/* Right Wing Content display */}
            <div className="lg:col-span-8 flex flex-col justify-between space-y-4">
              {activeTab === "certificate" ? (
                <div className="space-y-4">
                  <div>
                    <h4 className="text-lg font-bold text-white flex items-center gap-1.5">
                      {branchData[selectedBranch].certificate.title}
                      <span className="text-[10px] bg-[#10b981]/20 text-[#34d399] border border-[#10b981]/30 px-2 py-0.5 rounded font-mono">Free Track Available</span>
                    </h4>
                    <p className="text-xs text-[#94a3b8] font-mono mt-0.5">Target: {branchData[selectedBranch].certificate.audience}</p>
                  </div>

                  <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-2">
                    <h5 className="text-[#38bdf8] text-xs font-bold font-mono tracking-wider uppercase">Detailed Module Checklist</h5>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1">
                      {branchData[selectedBranch].certificate.courses.map((course: string, idx: number) => (
                        <li key={idx} className="text-xs text-[#cbd5e1] flex items-center gap-2">
                          <span className="h-1.5 w-1.5 bg-[#38bdf8] rounded-full" />
                          {course}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-1">
                    <h5 className="text-[#fbbf24] text-xs font-bold font-mono tracking-wider uppercase">Outcome Milestones</h5>
                    <p className="text-xs text-[#cbd5e1] leading-relaxed">
                      {branchData[selectedBranch].certificate.outcomes}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <h4 className="text-lg font-bold text-white flex items-center gap-1.5">
                      {branchData[selectedBranch].diploma.title}
                      <span className="text-[10px] bg-[#3b82f6]/20 text-[#60a5fa] border border-[#3b82f6]/30 px-2 py-0.5 rounded font-mono">Premium Course</span>
                    </h4>
                    <p className="text-xs text-[#94a3b8] font-mono mt-0.5">Target: {branchData[selectedBranch].diploma.audience}</p>
                  </div>

                  <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-2">
                    <h5 className="text-[#a855f7] text-xs font-bold font-mono tracking-wider uppercase">Curriculum Roadmap & Electives</h5>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1">
                      {branchData[selectedBranch].diploma.courses.map((course: string, idx: number) => (
                        <li key={idx} className="text-xs text-[#cbd5e1] flex items-center gap-2">
                          <span className="h-1.5 w-1.5 bg-[#c084fc] rounded-full" />
                          {course}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-2.5">
                    <h5 className="text-[#f43f5e] text-xs font-bold font-mono tracking-wider uppercase">Adaptive Engineering Tracks</h5>
                    <div className="space-y-1.5 font-mono text-[11px]">
                      <p className="text-[#cbd5e1]"><strong className="text-white">🎓 Freshers Track:</strong> {branchData[selectedBranch].diploma.specializations.fresher}</p>
                      <p className="text-[#cbd5e1]"><strong className="text-white">💼 Pro Track:</strong> {branchData[selectedBranch].diploma.specializations.experienced}</p>
                      <p className="text-[#cbd5e1]"><strong className="text-white">🧑‍💼 Lead Track:</strong> {branchData[selectedBranch].diploma.specializations.manager}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Dynamic footer showing tuition fees structured correctly */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-3 pt-4 border-t border-[#334155] mt-2">
                <div>
                  <span className="text-[10px] text-[#94a3b8] font-mono tracking-wider block">COHORT INVESTMENT</span>
                  <span className="text-sm font-bold text-[#fbbf24] font-mono">
                    {activeTab === "certificate" ? branchData[selectedBranch].certificate.fees : branchData[selectedBranch].diploma.fees}
                  </span>
                </div>
                {isLoggedIn ? (
                  <div className="text-xs text-[#22c55e] bg-[#22c55e]/10 border border-[#22c55e]/20 px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-mono">
                    <span className="h-2 w-2 rounded-full bg-[#22c55e] animate-ping" />
                    Enrolled — Visit My LMS Classroom
                  </div>
                ) : (
                  <button
                    onClick={() => onSignupRequested(selectedBranch, "Fresher")}
                    className="text-xs bg-[#0ea5e9] hover:bg-[#0284c7] py-1.5 px-4 rounded-lg font-bold text-white tracking-wide transition-all font-mono flex items-center gap-1 cursor-pointer"
                  >
                    Enroll Now
                    <ArrowRight className="h-3 w-3" />
                  </button>
                )}
              </div>
            </div>

          </div>
        )}
      </section>

      {/* SECTION 3: Process Excellence Program cards (Six Sigma, Kaizen, 5S) */}
      <section className="space-y-6">
        <div>
          <h3 className="text-xl md:text-2xl font-extrabold text-white tracking-tight">Process Excellence Certified Programmes</h3>
          <p className="text-xs text-[#94a3b8] font-mono mt-1">Acquire globally accredited operational skills highly demanded by premium manufacturing, defense & IT networks</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bento-card justify-between hover:border-[#38bdf8]/60">
            <div className="space-y-3">
              <span className="text-[10px] bg-[#3b82f6]/20 text-[#60a5fa] border border-[#3b82f6]/30 px-2 py-0.5 rounded font-mono font-bold">Accredited Program</span>
              <h4 className="text-base font-extrabold text-white flex items-center gap-1.5">
                📊 Lean Six Sigma Belt Framework
              </h4>
              <p className="text-xs text-[#cbd5e1] leading-relaxed">
                Unlock rigorous process capability index parameters (Cp & Cpk), measurement system analyses (MSA), multi-vari charts, and DMAIC deployments.
              </p>
              <div className="pt-2 text-xs text-[#cbd5e1] space-y-1 font-mono">
                <div>💥 White / Yellow Belt (Awareness)</div>
                <div>⚡ Green Belt (DMAIC Practitioner)</div>
                <div>🚀 Black Belt (DOE Catalyst)</div>
              </div>
            </div>
            <div className="border-t border-[#334155] pt-3 flex items-center justify-between text-xs mt-4">
              <span className="text-[#fbbf24] font-mono font-semibold">Duration: 4 Weeks - 3 Months</span>
            </div>
          </div>

          <div className="bento-card justify-between hover:border-[#10b981]/60">
            <div className="space-y-3">
              <span className="text-[10px] bg-[#10b981]/20 text-[#34d399] border border-[#10b981]/30 px-2 py-0.5 rounded font-mono font-bold">Continuous Improvement</span>
              <h4 className="text-base font-extrabold text-white flex items-center gap-1.5">
                🔄 Kaizen Operations Event (CI)
              </h4>
              <p className="text-xs text-[#cbd5e1] leading-relaxed">
                Learn continuous small refinements to completely eliminate waste (Muda), map value stream architectures (VSM), and increase overall machinery effectiveness (OEE).
              </p>
              <div className="pt-2 text-xs text-[#cbd5e1] space-y-1 font-mono">
                <div>📉 Waste Minimization & SOP Design</div>
                <div>📊 Value Stream Mapping (VSM)</div>
                <div>💫 Kaizen Event Workshop Leadership</div>
              </div>
            </div>
            <div className="border-t border-[#334155] pt-3 flex items-center justify-between text-xs mt-4">
              <span className="text-[#fbbf24] font-mono font-semibold">Duration: 1-2 Weeks Intensive</span>
            </div>
          </div>

          <div className="bento-card justify-between hover:border-[#eab308]/60">
            <div className="space-y-3">
              <span className="text-[10px] bg-[#eab308]/20 text-[#fde047] border border-[#eab308]/30 px-2 py-0.5 rounded font-mono font-bold">Workplace Discipline</span>
              <h4 className="text-base font-extrabold text-white flex items-center gap-1.5">
                🏭 5S Safety & Visual Audits
              </h4>
              <p className="text-xs text-[#cbd5e1] leading-relaxed">
                Establish robust housekeeping foundations: Sort (Seiri), Set in Order (Seiton), Shine (Seiso), Standardise (Seiketsu), and Sustain (Shitsuke) alongside advanced visual layouts.
              </p>
              <div className="pt-2 text-xs text-[#cbd5e1] space-y-1 font-mono">
                <div>🧹 Sort & Set Visual Systems</div>
                <div>🔍 5S Internal Auditor Certification</div>
                <div>⚠️ Workplace Safety Integration Standard</div>
              </div>
            </div>
            <div className="border-t border-[#334155] pt-3 flex items-center justify-between text-xs mt-4">
              <span className="text-[#fbbf24] font-mono font-semibold">Accreditation: Internationally Recognized</span>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: Placement Dashboard Outcomes */}
      <section className="bg-[#1e293b] border border-[#334155] rounded-3xl p-6 md:p-8 space-y-6 shadow-xl">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h3 className="text-xl md:text-2xl font-extrabold text-white tracking-tight flex items-center justify-center gap-2">
            🏆 Real Placement Ticker & Corporate Outcomes
          </h3>
          <p className="text-xs text-[#94a3b8] font-mono">Corporate hiring dashboard updated in real-time across PAN-India engineering and manufacturing firms</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="p-5 bg-[#0f172a] rounded-2xl border border-[#334155]/60 hover:border-[#38bdf8] transition-all">
            <span className="text-3xl font-black text-sky-400 font-mono">500+</span>
            <p className="text-[10px] text-[#94a3b8] font-mono font-bold mt-1 uppercase tracking-wider">STUDENTS PLACED</p>
          </div>
          <div className="p-5 bg-[#0f172a] rounded-2xl border border-[#334155]/60 hover:border-[#38bdf8] transition-all">
            <span className="text-3xl font-black text-[#10b981] font-mono">85%+</span>
            <p className="text-[10px] text-[#94a3b8] font-mono font-bold mt-1 uppercase tracking-wider">PLACEMENT SPEED RATE</p>
          </div>
          <div className="p-5 bg-[#0f172a] rounded-2xl border border-[#334155]/60 hover:border-[#38bdf8] transition-all">
            <span className="text-3xl font-black text-[#fbbf24] font-mono">₹8 LPA</span>
            <p className="text-[10px] text-[#94a3b8] font-mono font-bold mt-1 uppercase tracking-wider">AVERAGE PACKAGE SIZE</p>
          </div>
          <div className="p-5 bg-[#0f172a] rounded-2xl border border-[#334155]/60 hover:border-[#38bdf8] transition-all">
            <span className="text-3xl font-black text-[#f43f5e] font-mono">200+</span>
            <p className="text-[10px] text-[#94a3b8] font-mono font-bold mt-1 uppercase tracking-wider">HIRING PARTNERS</p>
          </div>
        </div>

        {/* List of branch specific recruiters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 text-xs">
          <div className="p-4 bg-[#0f172a] rounded-xl border border-[#334155] space-y-2">
            <h5 className="font-extrabold text-white font-mono text-xs text-[#38bdf8]">⚡ Electrical & Telecom Sectors</h5>
            <p className="text-[#cbd5e1] leading-relaxed text-[11px]">ABB, Siemens, Schneider Electric, NTPC, PowerGrid Corporation, Adani Green, Telecom giants (Jio, Airtel, Nokia, Ericsson)</p>
          </div>
          <div className="p-4 bg-[#0f172a] rounded-xl border border-[#334155] space-y-2">
            <h5 className="font-extrabold text-white font-mono text-xs text-[#10b981]">⚙️ Mech & Civil Infrastructure</h5>
            <p className="text-[#cbd5e1] leading-relaxed text-[11px]">L&T Construction, Shapoorji Pallonji, NHAI, Tata Motors, Cummins, HAL Aerospace, Bosch, DLF Realties, Afcons Contracting</p>
          </div>
          <div className="p-4 bg-[#0f172a] rounded-xl border border-[#334155] space-y-2">
            <h5 className="font-extrabold text-white font-mono text-xs text-[#c084fc]">💻 Software & Semiconductors</h5>
            <p className="text-[#cbd5e1] leading-relaxed text-[11px]">Qualcomm Integration Labs, Samsung Electronics, Texas Instruments, AWS, Honeywell Systems, FAANG setups, TCS, Google Aerospace</p>
          </div>
        </div>
      </section>
    </div>
  );
}
