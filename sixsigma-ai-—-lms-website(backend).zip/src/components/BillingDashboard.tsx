/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  CreditCard, 
  Check, 
  ShieldAlert, 
  Lock, 
  Coins, 
  Sparkles, 
  ArrowRight,
  TrendingUp,
  Cpu,
  BadgeAlert,
  Loader2
} from "lucide-react";
import { UserSafe } from "../types";

interface BillingDashboardProps {
  user: UserSafe | null;
  onPaymentSuccessSimulated: () => void;
  token: string | null;
  onOpenAuth: () => void;
}

export default function BillingDashboard({
  user,
  onPaymentSuccessSimulated,
  token,
  onOpenAuth,
}: BillingDashboardProps) {
  const [loading, setLoading] = useState<boolean>(false);
  const [simulationParams, setSimulationParams] = useState<{ userId: string; courseId: string } | null>(null);
  const [cardNumber, setCardNumber] = useState<string>("4242 •••• •••• 4242");
  const [cardName, setCardName] = useState<string>("");
  const [simMessage, setSimMessage] = useState<string>("");
  const [billingError, setBillingError] = useState<string>("");

  const handleCheckoutIntent = async (courseId: string) => {
    if (!user) {
      onOpenAuth();
      return;
    }

    setLoading(true);
    setSimMessage("");
    setBillingError("");
    try {
      const response = await fetch("/api/payments/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ courseId }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Checkout routing failure");
      }

      if (data.isSimulation) {
        // Intercept simulated response and render the mock credit card checkout immediately
        setSimulationParams({ userId: user.id, courseId });
        setCardName(user.name);
      } else if (data.url) {
        // If Stripe keys are configured, redirect straight to their genuine Stripe Checkout Session URL
        window.location.href = data.url;
      }
    } catch (err: any) {
      setBillingError(`Stripe Integration Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const submitSimulatedPaymentWebhook = async () => {
    if (!simulationParams) return;
    setLoading(true);
    setBillingError("");
    try {
      const response = await fetch("/api/payments/simulate-success", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          userId: simulationParams.userId,
          courseId: simulationParams.courseId,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Simulation webhook fail");
      }

      setSimMessage(data.message);
      // Fire success trigger to update overall state in main App level parent component
      setTimeout(() => {
        onPaymentSuccessSimulated();
        setSimulationParams(null);
        setSimMessage("");
      }, 3500);

    } catch (err: any) {
      setBillingError(`Simulation failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-12 pb-16">
      
      {/* Dynamic Simulation Interceptor UI */}
      {simulationParams && (
        <div className="bg-[#0b0f19] border-2 border-[#fbbf24]/50 rounded-2xl p-6 md:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#fbbf24]/5 rounded-full blur-[50px]" />
          
          <div className="md:col-span-7 space-y-4">
            <span className="text-[10px] bg-[#fbbf24]/20 text-[#fbbf24] border border-[#fbbf24]/30 px-2 py-0.5 rounded font-mono uppercase tracking-wider">
              Stripe Sandbox Interactive Emulator
            </span>
            <h3 className="text-xl md:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <CreditCard className="h-6 w-6 text-[#818cf8]" />
              Secure Gateway Simulation
            </h3>
            <p className="text-xs text-[#cbd5e1] leading-relaxed">
              Because no external credentials are pre-configured in this container environment, Sixsigma AI has generated this interactive Stripe payment bypass window. 
              Submitting the coupon simulates a complete card transaction and directs a signed <strong>checkout.session.completed</strong> metadata payload to our Express webhook in real-time.
            </p>

            <div className="p-4 bg-[#111827] rounded-xl border border-[#222936] space-y-2 text-xs">
              <div className="flex justify-between font-mono">
                <span className="text-[#8a99ad]">Syllabus Upgrade Target:</span>
                <span className="text-white font-bold">{simulationParams.courseId}</span>
              </div>
              <div className="flex justify-between font-mono">
                <span className="text-[#8a99ad]">Assigned Learner ID:</span>
                <span className="text-white font-bold">{simulationParams.userId}</span>
              </div>
              <div className="border-t border-[#1e293b] pt-2 flex justify-between font-mono text-sm">
                <span className="text-[#8a99ad]">Payment Fee Amount:</span>
                <span className="text-[#fbbf24] font-bold">$49.00 USD</span>
              </div>
            </div>

            {simMessage ? (
              <div className="p-4 rounded-xl bg-[#10b981]/15 border border-[#10b981]/30 text-xs text-[#34d399] leading-relaxed animate-pulse">
                {simMessage}
              </div>
            ) : (
              <button
                id="btn-submit-payment-sim"
                onClick={submitSimulatedPaymentWebhook}
                disabled={loading}
                className="w-full bg-[#3b82f6] hover:bg-[#2563eb] py-2.5 rounded-lg text-xs text-white font-extrabold tracking-wider font-mono flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Approve Simulated Stripe Checkout"}
              </button>
            )}
            
            <button
              onClick={() => setSimulationParams(null)}
              className="text-xs text-[#abb9cd] hover:underline block font-mono"
            >
              Cancel Sandbox Session
            </button>
          </div>

          {/* Visual credit card graphic */}
          <div className="md:col-span-5 flex items-center justify-center">
            <div className="w-full max-w-sm bg-gradient-to-tr from-[#1e293b] via-[#334155] to-[#1e293b] p-6 rounded-xl border border-[#475569]/30 shadow-2xl relative space-y-6">
              <div className="flex justify-between items-start">
                <span className="text-[10px] text-[#cbd5e1] font-mono leading-none">TEST MODE CONTROL</span>
                <div className="text-sm font-bold text-[#818cf8]">VISA</div>
              </div>
              
              <div className="font-mono text-sm text-white tracking-widest">{cardNumber}</div>
              
              <div className="flex justify-between items-end">
                <div>
                  <span className="text-[8px] text-[#8a99ad] uppercase block">CARDHOLDER</span>
                  <span className="font-mono text-[10px] text-white font-medium">{cardName.toUpperCase() || "ENGINEER LEADER"}</span>
                </div>
                <div>
                  <span className="text-[8px] text-[#8a99ad] uppercase block">EXPIRES</span>
                  <span className="font-mono text-[10px] text-white">05 / 29</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pricing Header */}
      <section className="text-center max-w-2xl mx-auto space-y-3">
        <h3 className="text-2xl md:text-3xl font-bold text-white tracking-tight">Structured Professional Tuition</h3>
        <p className="text-xs text-[#8a99ad] font-mono leading-relaxed">
          Upgrade your catalog from the Standard Certificate to secure verified diplomas, permanent watch tracking database states, and unlimited expert AI mentorship
        </p>
      </section>

      {/* Grid comparing free vs premium paths */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        
        {/* Plan 1: Free Certificate Pathway */}
        <div className="bg-[#111827] border border-[#222936] rounded-2xl p-6 flex flex-col justify-between space-y-6 relative overflow-hidden">
          <div className="space-y-4">
            <div>
              <span className="text-[9px] bg-[#475569]/20 text-[#94a3b8] px-2 py-0.5 rounded font-mono uppercase tracking-wide">STANDARD DIRECT</span>
              <h4 className="text-lg font-bold text-white mt-1.5">Free Learning Pathway</h4>
              <p className="text-xs text-[#8a99ad] font-mono mt-0.5">₹0  │  Syllabus Explorer Access</p>
            </div>

            <p className="text-xs text-[#cbd5e1] leading-relaxed">
              Provides fundamental educational check, basic interactive quiz verification, and curriculum review for early engineers.
            </p>

            <ul className="space-y-2 text-xs text-[#cbd5e1] pt-2">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                Access to 3 core modules based on branch selection
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                Simulated video player watch state caching
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                Automated quiz scoring and basic verification limits
              </li>
              <li className="flex items-center gap-2 text-[#475569]">
                <Lock className="h-3.5 w-3.5 text-[#475569] shrink-0" />
                Advanced EV technology BMS syllabus locked
              </li>
              <li className="flex items-center gap-2 text-[#475569]">
                <Lock className="h-3.5 w-3.5 text-[#475569] shrink-0" />
                Dedicated placement mock testing panel locked
              </li>
            </ul>
          </div>

          <div className="border-t border-[#1f293d] pt-4 mt-2">
            <button
              disabled
              className="w-full bg-[#1c2230] text-[#cbd5e1] border border-[#2e3748] py-2.5 rounded-lg text-xs font-semibold font-mono uppercase tracking-wider"
            >
              Current Standard Plan
            </button>
          </div>
        </div>

        {/* Plan 2: Premium PG Diploma Upgrade */}
        <div className="bg-[#111827] border-2 border-[#4f46e5]/40 rounded-2xl p-6 flex flex-col justify-between space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#4a3cf5]/10 rounded-full blur-[40px]" />
          
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[9px] bg-[#edb823]/20 text-[#fbbf24] border border-[#edb823]/30 px-2 py-0.5 rounded font-mono uppercase tracking-wide">
                  RECOMMENDED UPGRADE
                </span>
                <h4 className="text-lg font-bold text-white mt-1.5">Universal Premium Core</h4>
                <p className="text-xs text-[#fbbf24] font-mono mt-0.5">$49.00 Flat  │  Permanent Lifetime Upgrade</p>
              </div>
              <Sparkles className="h-5 w-5 text-[#fbbf24]" />
            </div>

            <p className="text-xs text-[#cbd5e1] leading-relaxed">
              Unlock the entire Advanced Professional Syllabus (EV batteries, robotics, continuous improvement systems, big data models) and access unlimited expert AI coach conversations.
            </p>

            <ul className="space-y-2 text-xs text-[#cbd5e1] pt-2">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                <strong>Unlock All Branches</strong> Premium & Specialization Streams
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                Uninhibited AI Tutor coaching sessions
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                Advanced Tools training check (MATLAB, STAAD Pro, Revit, Git)
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                Permanent progress database persistence
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-[#10b981]" />
                Blockchain-verified Certifications & Placement Board
              </li>
            </ul>
          </div>

          <div className="border-t border-[#4f46e5]/20 pt-4 mt-2 space-y-3">
            {billingError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/25 text-[11px] text-rose-400 font-mono rounded-xl leading-relaxed">
                ⚠️ {billingError}
              </div>
            )}
            {user?.isPremiumUnlocked ? (
              <button
                disabled
                className="w-full bg-[#10b981]/20 text-[#34d399] border-2 border-[#10b981]/30 py-2.5 rounded-lg text-xs font-semibold font-mono uppercase tracking-wider flex items-center justify-center gap-2"
              >
                ✔ Premium Unlocked via Webhook
              </button>
            ) : (
              <button
                id="btn-pricing-upgrade"
                onClick={() => handleCheckoutIntent("pe-six-sigma-green")}
                disabled={loading}
                className="w-full bg-[#4f46e5] text-white hover:bg-[#4338ca] py-2.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer transition-all shadow-lg shadow-[#4f46e5]/10 animate-pulse"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Unlock Premium via Stripe"}
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
