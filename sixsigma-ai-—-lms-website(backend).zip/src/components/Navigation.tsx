/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  Award, 
  BookOpen, 
  Compass, 
  MessageSquare, 
  CreditCard, 
  LogOut, 
  User, 
  Zap, 
  Activity,
  ShieldCheck
} from "lucide-react";
import { UserSafe, ViewTab } from "../types";

interface NavigationProps {
  user: UserSafe | null;
  activeTab: ViewTab;
  setActiveTab: (tab: ViewTab) => void;
  onLogout: () => void;
  onOpenAuth: () => void;
}

export default function Navigation({
  user,
  activeTab,
  setActiveTab,
  onLogout,
  onOpenAuth,
}: NavigationProps) {
  return (
    <header className="sticky top-0 z-50 bg-[#1e293b]/95 backdrop-blur-md border-b border-[#334155] px-4 py-3">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Branding Title */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab("home")}>
          <div className="p-2.5 bg-[#0ea5e9]/15 rounded-xl border border-[#38bdf8]/30">
            <Award className="h-6 w-6 text-[#38bdf8] animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-extrabold text-white tracking-widest flex items-center gap-1.5 uppercase font-mono">
              SIXSIGMA AI <span className="text-[10px] bg-[#0ea5e9] text-white px-2 py-0.5 rounded-md font-mono font-bold tracking-normal">v1.1-BENTO</span>
            </h1>
            <p className="text-[10px] text-[#94a3b8] font-mono leading-none">Engineering PG Programmes & Quality Excellence</p>
          </div>
        </div>

        {/* Dynamic View Tab Toggles */}
        <nav className="flex flex-wrap items-center gap-1.5">
          <button
            id="nav-btn-home"
            onClick={() => setActiveTab("home")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all font-mono ${
              activeTab === "home"
                ? "bg-[#0ea5e9] text-white border border-[#38bdf8]"
                : "text-slate-400 hover:text-white hover:bg-[#334155]/50"
            }`}
          >
            <Compass className="h-3.5 w-3.5" />
            Outcomes & Sectors
          </button>

          <button
            id="nav-btn-syllabus"
            onClick={() => setActiveTab("syllabus")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all font-mono ${
              activeTab === "syllabus"
                ? "bg-[#0ea5e9] text-white border border-[#38bdf8]"
                : "text-slate-400 hover:text-white hover:bg-[#334155]/50"
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            PG Programmes
          </button>

          {user && (
            <>
              <button
                id="nav-btn-dashboard"
                onClick={() => setActiveTab("dashboard")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all font-mono ${
                  activeTab === "dashboard"
                    ? "bg-[#0ea5e9] text-white border border-[#38bdf8]"
                    : "text-slate-400 hover:text-white hover:bg-[#334155]/50"
                }`}
              >
                <Activity className="h-3.5 w-3.5" />
                LMS Classroom
              </button>

              <button
                id="nav-btn-ai"
                onClick={() => setActiveTab("ai-tutor")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all font-mono ${
                  activeTab === "ai-tutor"
                    ? "bg-[#0ea5e9] text-white border border-[#38bdf8]"
                    : "text-slate-400 hover:text-white hover:bg-[#334155]/50"
                }`}
              >
                <MessageSquare className="h-3.5 w-3.5" />
                24/7 AI Tutor
              </button>
            </>
          )}

          <button
            id="nav-btn-billing"
            onClick={() => setActiveTab("billing")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all font-mono ${
              activeTab === "billing"
                ? "bg-[#0ea5e9] text-white border border-[#38bdf8]"
                : "text-slate-400 hover:text-white hover:bg-[#334155]/50"
            }`}
          >
            <CreditCard className="h-3.5 w-3.5" />
            Billing & Premium
          </button>
        </nav>

        {/* User Context Area */}
        <div className="flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-2">
              <div className="hidden lg:flex flex-col items-end text-right">
                <span className="text-xs font-bold text-white tracking-tight">{user.name}</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[10px] bg-[#fbbf24]/20 text-[#fbbf24] border border-[#fbbf24]/30 px-1.5 py-0.5 rounded font-mono">
                    {user.track === "Fresher" ? "🎓 Fresher" : user.track === "Experienced" ? "💼 Pro" : "🧑‍💼 Lead"}
                  </span>
                  <span className="text-[10px] bg-[#3b82f6]/20 text-[#60a5fa] border border-[#3b82f6]/30 px-1.5 py-0.5 rounded font-mono">
                    {user.branch}
                  </span>
                  {user.isPremiumUnlocked && (
                    <span className="text-[10px] bg-[#10b981]/20 text-[#34d399] border border-[#10b981]/30 px-2 rounded-full flex items-center gap-0.5 font-mono">
                      <ShieldCheck className="h-2.5 w-2.5" />
                      Premium
                    </span>
                  )}
                </div>
              </div>
              <button
                id="btn-logout"
                onClick={onLogout}
                className="p-1 px-2.5 border border-[#fc8181]/30 bg-[#fc8181]/5 text-xs text-[#fc8181] rounded-lg hover:bg-[#fc8181]/20 transition-all flex items-center gap-1.5 font-mono"
                title="Log out"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <button
              id="btn-login"
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white border border-[#38bdf8]/50 bg-gradient-to-r from-[#0ea5e9] to-[#4f46e5] hover:opacity-90 shadow-lg shadow-[#0ea5e9]/10 transition-all cursor-pointer font-mono"
            >
              <User className="h-3.5 w-3.5" />
              Sign In / Enroll
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
