/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { 
  Send, 
  MessageSquare, 
  Cpu, 
  RefreshCw, 
  Sparkles, 
  HelpCircle,
  Clock,
  ShieldCheck,
  AlertTriangle
} from "lucide-react";
import { UserSafe } from "../types";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  isMocked?: boolean;
  timestamp: string;
}

interface AiTutorProps {
  user: UserSafe;
  token: string | null;
}

export default function AiTutor({ user, token }: AiTutorProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputVal, setInputVal] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activePersonaInfo, setActivePersonaInfo] = useState<string>("");

  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Load Persona Welcoming Message
  useEffect(() => {
    const welcomeText = `Hello **${user.name}**! I am your Sixsigma AI Engineering Mentor. 

Since you are enrolled in the **${user.track} Track** of the **${user.branch} Engineering** department, I am specializing my guidelines in:
- **Core Engineering:** Calculations, optimization, and software verification tools.
- **Process Excellence Models:** Lean Six Sigma, DMAIC, 5S Auditing, and Kaizen.
- **Career Growth:** Technical mock prep, resume keywords, and real-case scenarios.

What technical concept can I clarify for you today?`;

    setMessages([
      {
        id: "wel_01",
        role: "assistant",
        text: welcomeText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }
    ]);

    setActivePersonaInfo(`Branch Coaching: ${user.branch}  │  Focus Track: ${user.track}`);
  }, [user.name, user.branch, user.track]);

  // Scroll chat messages to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputVal.trim() || isLoading) return;

    const userMessageText = inputVal.trim();
    setInputVal("");
    setIsLoading(true);

    const userMsgObj: ChatMessage = {
      id: "msg_" + Math.random().toString(36).substr(2, 9),
      role: "user",
      text: userMessageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsgObj]);

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          message: userMessageText,
          chatHistory: messages.map((m) => ({
            role: m.role,
            text: m.text,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error("Tutor connection timed out or database was unreachable.");
      }

      const data = await response.json();

      const assistantMsgObj: ChatMessage = {
        id: "msg_" + Math.random().toString(36).substr(2, 9),
        role: "assistant",
        text: data.message,
        isMocked: data.isMocked,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsgObj]);
    } catch (err: any) {
      const errorMsgObj: ChatMessage = {
        id: "msg_" + Math.random().toString(36).substr(2, 9),
        role: "assistant",
        text: `⚠️ **Session Connection Offline:** ${err.message}. Please verify local container hosting or secrets parameters.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsgObj]);
    } finally {
      setIsLoading(false);
    }
  };

  const selectSuggestedPrompt = (prompt: string) => {
    setInputVal(prompt);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-16">
      
      {/* LHS Chat Panel component */}
      <div className="lg:col-span-8 bg-[#111827] border border-[#222936] rounded-2xl flex flex-col h-[600px] overflow-hidden">
        
        {/* Tutor window header status */}
        <div className="bg-[#1a2234] border-b border-[#222936] p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-[#4f46e5]/10 border border-[#4f46e5]/30 flex items-center justify-center">
              <Cpu className="h-4 w-4 text-[#818cf8]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white leading-tight">Interactive AI Engineering Coach</h3>
              <p className="text-[10px] text-[#fbbf24] font-mono leading-none mt-1">{activePersonaInfo}</p>
            </div>
          </div>

          <button
            id="btn-clear-chat"
            onClick={() => {
              setMessages([
                {
                  id: "wel_01",
                  role: "assistant",
                  text: `Welcome back, **${user.name}**! Chat is reset, I am updated and ready. How may I support you?`,
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                }
              ]);
            }}
            className="p-1 px-2.5 text-[10px] bg-[#111827] text-[#cbd5e1] hover:text-white border border-[#222936] rounded font-mono"
            title="Reset history context"
          >
            Clear History
          </button>
        </div>

        {/* Scrollable message container block */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => {
            const isUser = message.role === "user";
            return (
              <div
                key={message.id}
                className={`flex gap-3 max-w-[85%] ${isUser ? "ml-auto flex-row-reverse" : "mr-auto"}`}
              >
                {/* Visual Avatar icons */}
                <div className={`h-8 w-8 rounded-lg shrink-0 flex items-center justify-center border font-mono text-[10px] ${
                  isUser 
                    ? "bg-[#1f293d] border-[#3b82f6]/30 text-white" 
                    : "bg-[#4f46e5]/10 border-[#4f46e5]/30 text-[#818cf8]"
                }`}>
                  {isUser ? "ME" : "AI"}
                </div>

                {/* Message safe content */}
                <div className="space-y-1">
                  <div className={`p-4 rounded-2xl text-xs leading-relaxed space-y-2 whitespace-pre-line ${
                    isUser 
                      ? "bg-[#1d4ed8] text-white rounded-tr-none" 
                      : "bg-[#161f30] text-[#cbd5e1] border border-[#222936] rounded-tl-none"
                  }`}>
                    {message.text}

                    {message.isMocked && (
                      <span className="block border-t border-[#1e293b] pt-2 mt-2 text-[9px] text-[#8a99ad] font-mono uppercase tracking-wider flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3 text-[#fbbf24]" />
                        Local Fallback Assist (Mock mode active)
                      </span>
                    )}
                  </div>
                  <div className={`text-[9px] text-[#475569] font-mono ${isUser ? "text-right" : "text-left"}`}>
                    {message.timestamp}
                  </div>
                </div>

              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 max-w-[85%] mr-auto items-center">
              <div className="h-8 w-8 rounded-lg bg-[#4f46e5]/10 border border-[#4f46e5]/30 flex items-center justify-center text-[#818cf8] font-mono text-[10px] animate-spin">
                <RefreshCw className="h-3 w-3" />
              </div>
              <span className="text-xs text-[#8a99ad] font-mono animate-pulse">Tutor is analyzing calculations...</span>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Input box form */}
        <form onSubmit={handleSendMessage} className="bg-[#161f30] border-t border-[#222936] p-3 flex gap-2">
          <input
            id="tutor-chat-input"
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder={`Ask a doubt on ${user.branch} curriculum or Six Sigma Belt concepts...`}
            className="flex-1 bg-[#0b0f19] border border-[#222936] rounded-xl px-4 py-2.5 text-xs text-white outline-none placeholder-[#475569]"
            disabled={isLoading}
          />
          <button
            id="btn-chat-send"
            type="submit"
            disabled={!inputVal.trim() || isLoading}
            className="bg-[#4f46e5] hover:bg-[#4338ca] disabled:opacity-50 text-white rounded-xl px-4 flex items-center justify-center cursor-pointer transition-all shrink-0"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>

      </div>

      {/* RHS Suggested doubts prompts card */}
      <div className="lg:col-span-4 space-y-6">
        
        {/* Status indicator showing API check */}
        <div className="bg-[#111827] border border-[#222936] rounded-xl p-5 space-y-3">
          <h4 className="text-white text-xs font-bold uppercase tracking-wider font-mono text-[#8a99ad]">Tutor Engine Health</h4>
          
          <div className="p-3.5 bg-[#0b0f19] border border-[#1e293b] rounded-lg space-y-2">
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-[#10b981]" />
              <span className="text-white text-xs font-semibold leading-none">Server Controller Live</span>
            </div>
            <p className="text-[10px] text-[#cbd5e1] leading-relaxed">
              Express controllers successfully mounted. If Gemini API key is mapped in Secrets tab, actual LLM intelligence completes queries.
            </p>
          </div>
        </div>

        {/* List of recommended quick prompts */}
        <div className="bg-[#111827] border border-[#222936] rounded-xl p-5 space-y-3.5">
          <h4 className="text-white text-xs font-bold font-mono tracking-wider uppercase border-b border-[#222936] pb-1">
            Recommended Doubts
          </h4>

          <div className="space-y-2">
            {user.branch === "Electrical" && (
              <>
                <button
                  onClick={() => selectSuggestedPrompt("Explain PMU calibration requirements inside a smart grid layout.")}
                  className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
                >
                  ⚡ PMU Smart Grid calibration checks
                </button>
                <button
                  onClick={() => selectSuggestedPrompt("How does passive balancing compare to active BMS for EV arrays?")}
                  className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
                >
                  🔋 EV Cell Balancing differences
                </button>
              </>
            )}

            {user.branch === "Mechanical" && (
              <>
                <button
                  onClick={() => selectSuggestedPrompt("How do I establish stress limit constraints in ANSYS structural FEA?")}
                  className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
                >
                  ⚙️ ANSYS Stress constraints guide
                </button>
                <button
                  onClick={() => selectSuggestedPrompt("Explain kinematic Digital Twin calibration flow inside Siemens NX.")}
                  className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
                >
                  🤖 Kinematic Digital Twin NX calibration
                </button>
              </>
            )}

            {user.branch === "Civil" && (
              <>
                <button
                  onClick={() => selectSuggestedPrompt("What standard concrete strain calculations govern IS 456 / ACI-318 reinforced columns?")}
                  className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
                >
                  🏗️ Reinforcement standard IS 456
                </button>
                <button
                  onClick={() => selectSuggestedPrompt("Explain AutoCAD Revit BIM data coordination flow using Navisworks.")}
                  className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
                >
                  🧱 Navisworks BIM coordinate flow
                </button>
              </>
            )}

            <button
              onClick={() => selectSuggestedPrompt("What is the difference between Cp & Cpk indexes in Six Sigma DMAIC analyses?")}
              className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
            >
              📊 Cp vs Cpk Capability analytics
            </button>
            <button
              onClick={() => selectSuggestedPrompt("Describe the 5 stages of a rapid 5-day Kaizen Continuous Improvement Event.")}
              className="w-full text-left p-3 bg-[#0b0f19] hover:bg-[#1f293d] rounded-lg border border-[#1e293b] text-xs text-[#cbd5e1] leading-relaxed transition-all cursor-pointer block"
            >
              🔄 Anatomy of a 5-Day Kaizen Event
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
