/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Play, 
  CheckCircle, 
  Circle, 
  Award, 
  HelpCircle, 
  Clock, 
  Video, 
  BookOpen, 
  Compass, 
  AlertCircle,
  TrendingUp,
  Cpu,
  ChevronRight,
  Loader2
} from "lucide-react";
import { Course, UserSafe, UserProgress, Lesson, QuizQuestion } from "../types";

interface CoursePlayerProps {
  user: UserSafe;
  courses: Course[];
  progressList: UserProgress[];
  onProgressUpdated: (courseId: string, lessonId: string, completed: boolean, watchPercent: number, score?: number) => void;
  token: string | null;
}

export default function CoursePlayer({
  user,
  courses,
  progressList,
  onProgressUpdated,
  token,
}: CoursePlayerProps) {
  // Filter courses based on user's selected branch, or process excellence programs
  const userCourses = courses.filter(
    (c) => c.branch.toLowerCase() === user.branch.toLowerCase() || c.branch === "Process Excellence"
  );

  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [simulatedWatch, setSimulatedWatch] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [syncLoading, setSyncLoading] = useState<boolean>(false);
  const [syncError, setSyncError] = useState<string>("");

  const syncProgress = async (
    courseId: string,
    lessonId: string,
    completed: boolean,
    watchPercent: number,
    score?: number
  ) => {
    // Sync React states first to provide ultra-responsive local updates
    onProgressUpdated(courseId, lessonId, completed, watchPercent, score);

    if (token) {
      setSyncLoading(true);
      setSyncError("");
      try {
        const response = await fetch("/api/user/progress", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            courseId,
            lessonId,
            completed,
            watchPercent,
            score,
          }),
        });

        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.error || "LMS Sync rejected server handshake.");
        }
      } catch (err: any) {
        setSyncError(err.message || "Failed auto-syncing progress.");
        console.error("CoursePlayer Progress API Endpoint POST error:", err);
      } finally {
        setSyncLoading(false);
      }
    }
  };

  // Default active selection on mount
  useEffect(() => {
    if (userCourses.length > 0 && !activeCourse) {
      setActiveCourse(userCourses[0]);
      if (userCourses[0].modules.length > 0 && userCourses[0].modules[0].lessons.length > 0) {
        setActiveLesson(userCourses[0].modules[0].lessons[0]);
      }
    }
  }, [userCourses, activeCourse]);

  // Handle active lesson selection modifications
  useEffect(() => {
    if (activeLesson) {
      // Find current watch progress if already tracked in DB
      const tracking = progressList.find(
        (p) => p.courseId === activeCourse?.id && p.lessonId === activeLesson.id
      );
      setSimulatedWatch(tracking ? tracking.watchPercent : 0);
      setIsPlaying(false);
      setQuizAnswers({});
      setQuizScore(tracking?.score !== undefined ? tracking.score : null);
      setQuizSubmitted(tracking?.score !== undefined);
    }
  }, [activeLesson, activeCourse, progressList]);

  // Video playback simulator logic
  useEffect(() => {
    let interval: any = null;
    if (isPlaying && activeLesson && activeCourse) {
      interval = setInterval(() => {
        setSimulatedWatch((prev) => {
          const nextVal = Math.min(prev + 5, 100);
          if (nextVal === 100) {
            setIsPlaying(false);
            // Auto complete lesson watch state
            syncProgress(activeCourse.id, activeLesson.id, true, 100, quizScore !== null ? quizScore : undefined);
          } else if (nextVal % 20 === 0) {
            // Periodic update to sync watch percentage dynamically
            syncProgress(activeCourse.id, activeLesson.id, nextVal >= 90, nextVal, quizScore !== null ? quizScore : undefined);
          }
          return nextVal;
        });
      }, 800);
    }
    return () => clearInterval(interval);
  }, [isPlaying, activeLesson, activeCourse, quizScore]);

  if (userCourses.length === 0) {
    return (
      <div className="p-8 bg-[#111827] border border-[#222936] rounded-2xl text-center space-y-4">
        <AlertCircle className="h-10 w-10 text-[#eb5757] mx-auto animate-bounce" />
        <h3 className="text-white text-lg font-bold">Unmapped Engineering Course Pathway</h3>
        <p className="text-xs text-[#8a99ad] leading-relaxed max-w-sm mx-auto">
          We found no direct courses assigned to the branch **{user.branch}**. Update your profile branch or explore the Billing dashboard to unlock universal Process Excellence.
        </p>
      </div>
    );
  }

  const currentCourse = activeCourse || userCourses[0];
  const currentLesson = activeLesson || (currentCourse?.modules[0]?.lessons[0] || null);

  // Compute stats
  const totalLessons = currentCourse?.modules.reduce((sum, m) => sum + m.lessons.length, 0) || 0;
  const completedLessonsCount = progressList.filter(
    (p) => p.courseId === currentCourse?.id && p.completed
  ).length;
  const courseCompletionRate = totalLessons > 0 ? Math.round((completedLessonsCount / totalLessons) * 100) : 0;

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    setSimulatedWatch(val);
    if (currentCourse && currentLesson) {
      syncProgress(currentCourse.id, currentLesson.id, val >= 90, val, quizScore !== null ? quizScore : undefined);
    }
  };

  const handleSelectQuizAnswer = (qId: string, optIndex: number) => {
    setQuizAnswers((prev) => ({ ...prev, [qId]: optIndex }));
  };

  const handleSubmitQuiz = () => {
    if (!currentLesson?.quiz || !currentCourse) return;
    let correctCount = 0;
    currentLesson.quiz.forEach((q) => {
      if (quizAnswers[q.id] === q.correctOptionIndex) {
        correctCount += 1;
      }
    });

    const finalPercent = Math.round((correctCount / currentLesson.quiz.length) * 100);
    setQuizScore(finalPercent);
    setQuizSubmitted(true);

    // Sync score permanently to database
    syncProgress(currentCourse.id, currentLesson.id, true, Math.max(simulatedWatch, 90), finalPercent);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-16">
      
      {/* SECTION 1: LHS Main HD Media Simulator and Quiz */}
      <div className="lg:col-span-8 space-y-6">
        
        {/* Course dropdown toggle */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111827] border border-[#222936] p-4 rounded-xl">
          <div>
            <span className="text-[10px] text-[#fbbf24] font-mono tracking-wider">ACTIVE SYLLABUS DISCIPLINE</span>
            <div className="flex items-center gap-2 mt-0.5">
              <BookOpen className="h-4 w-4 text-[#818cf8]" />
              <h3 className="text-sm font-semibold text-white tracking-tight">{currentCourse?.title}</h3>
            </div>
          </div>
          
          <select
            id="course-selector"
            value={currentCourse?.id || ""}
            onChange={(e) => {
              const selected = userCourses.find((c) => c.id === e.target.value);
              if (selected) {
                setActiveCourse(selected);
                if (selected.modules.length > 0 && selected.modules[0].lessons.length > 0) {
                  setActiveLesson(selected.modules[0].lessons[0]);
                }
              }
            }}
            className="bg-[#1f2937] border border-[#2e3748] text-white text-xs px-3 py-1.5 rounded-lg outline-none cursor-pointer font-mono"
          >
            {userCourses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title.substring(0, 45)}...
              </option>
            ))}
          </select>
        </div>

        {/* Dynamic Video Player Mockup */}
        <div className="relative overflow-hidden rounded-2xl bg-[#0b0f19] border border-[#222936] aspect-video flex flex-col justify-between p-6">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#3b82f6]/5 rounded-full blur-[80px]" />

          {/* Player header */}
          <div className="flex items-center justify-between z-10">
            <div>
              <span className="text-[10px] bg-[#3b82f6]/30 text-[#818cf8] px-2 py-0.5 border border-[#3b82f6]/20 font-mono rounded">
                1080P Full HD Simulated Stream
              </span>
              <h4 className="text-white text-sm font-bold mt-1.5 tracking-tight flex items-center gap-1.5">
                <Video className="h-4 w-4 text-[#fbbf24]" />
                {currentLesson?.title}
              </h4>
            </div>
            
            {/* Status completeness chip */}
            <div className="flex flex-col items-end gap-1.5 font-mono text-xs">
              {syncLoading && (
                <span className="text-[9px] bg-sky-500/10 text-sky-400 border border-sky-400/20 px-2 py-0.5 rounded-md flex items-center gap-1 animate-pulse">
                  <Loader2 className="h-2.5 w-2.5 animate-spin" /> API SYNCHRONIZING
                </span>
              )}
              {syncError && (
                <span className="text-[9px] bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-md max-w-[120px] truncate" title={syncError}>
                  ❌ SYNC FAIL
                </span>
              )}
              {simulatedWatch >= 90 ? (
                <span className="text-[#10b981] bg-[#10b981]/10 px-2 py-0.5 border border-[#10b981]/20 rounded-full flex items-center gap-1">
                  <CheckCircle className="h-3.5 w-3.5" /> Checked
                </span>
              ) : (
                <span className="text-[#8a99ad] bg-[#222936] px-2.5 py-0.5 rounded-full">
                  {simulatedWatch}% Complete
                </span>
              )}
            </div>
          </div>

          {/* Central Play/Pause State graphics */}
          <div className="flex flex-col items-center justify-center py-8 z-10">
            {!isPlaying ? (
              <button
                id="btn-play-sim"
                onClick={() => setIsPlaying(true)}
                className="h-16 w-16 bg-[#4f46e5] text-white hover:bg-[#4338ca] hover:scale-105 rounded-full flex items-center justify-center shadow-lg shadow-[#4f46e5]/30 cursor-pointer transition-all"
              >
                <Play className="h-8 w-8 text-white fill-current ml-1" />
              </button>
            ) : (
              <div className="relative flex flex-col items-center">
                <div className="flex gap-1.5 items-end h-8">
                  <span className="w-1 bg-[#10b981] h-6 rounded-full animate-bounce" />
                  <span className="w-1 bg-[#10b981] h-3 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1 bg-[#10b981] h-8 rounded-full animate-bounce [animation-delay:0.4s]" />
                  <span className="w-1 bg-[#10b981] h-4 rounded-full animate-bounce [animation-delay:0.1s]" />
                </div>
                <button
                  id="btn-pause-sim"
                  onClick={() => setIsPlaying(false)}
                  className="mt-4 text-xs font-mono bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30 px-3 py-1 rounded hover:bg-[#ef4444]/30"
                >
                  Pause Simulator Stream
                </button>
              </div>
            )}
          </div>

          {/* Player controls */}
          <div className="space-y-3 z-10">
            {/* Timeline slider */}
            <div className="flex items-center gap-3">
              <span className="text-[10px] text-[#8a99ad] font-mono">00:00</span>
              <input
                id="watch-timeline"
                type="range"
                min="0"
                max="100"
                value={simulatedWatch}
                onChange={handleSeekChange}
                className="flex-1 accent-[#4f46e5] bg-[#1f2937] h-1 rounded-lg cursor-pointer"
              />
              <span className="text-[10px] text-[#8a99ad] font-mono">
                {currentLesson?.duration}
              </span>
            </div>

            {/* Simulated toolbelt */}
            <div className="flex justify-between items-center text-[10px] font-mono text-[#8a99ad]">
              <div className="flex items-center gap-4">
                <span>Speed: 1.0x</span>
                <span>Aspect: 16:9</span>
              </div>
              <button
                id="btn-fast-forward"
                onClick={() => {
                  setSimulatedWatch(95);
                  if (currentCourse && currentLesson) {
                    onProgressUpdated(currentCourse.id, currentLesson.id, true, 95, quizScore !== null ? quizScore : undefined);
                  }
                }}
                className="text-[#60a5fa] hover:underline"
              >
                ⏩ Fast Forward (Complete Watch Mode)
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Quiz Sheet Area directly below */}
        {currentLesson?.quiz && currentLesson.quiz.length > 0 && (
          <div className="bg-[#111827] border border-[#222936] rounded-xl p-6 space-y-4">
            <div className="flex items-center gap-2 border-b border-[#222936] pb-3">
              <HelpCircle className="h-5 w-5 text-[#818cf8]" />
              <div>
                <h4 className="text-white text-sm font-bold">Interactive Module Quiz Assessment</h4>
                <p className="text-[11px] text-[#8a99ad]">Complete this lesson module check to unlock placement credentials</p>
              </div>
            </div>

            <div className="space-y-6">
              {currentLesson.quiz.map((q: QuizQuestion, qIdx: number) => (
                <div key={q.id} className="space-y-3">
                  <h5 className="text-xs font-semibold text-white tracking-wide">
                    {qIdx + 1}. {q.question}
                  </h5>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {q.options.map((opt: string, optIdx: number) => {
                      const isSelected = quizAnswers[q.id] === optIdx;
                      const isCorrect = optIdx === q.correctOptionIndex;

                      let btnStyle = "bg-[#1f2937] text-white border-[#2e3748]";
                      if (isSelected) {
                        btnStyle = "bg-[#4f46e5]/20 text-white border-[#4f46e5]";
                      }
                      if (quizSubmitted) {
                        if (isCorrect) {
                          btnStyle = "bg-[#10b981]/20 text-white border-[#10b981] font-medium";
                        } else if (isSelected) {
                          btnStyle = "bg-[#ef4444]/20 text-white border-[#ef4444]";
                        }
                      }

                      return (
                        <button
                          key={optIdx}
                          disabled={quizSubmitted}
                          onClick={() => handleSelectQuizAnswer(q.id, optIdx)}
                          className={`text-left p-3.5 rounded-lg border text-xs leading-relaxed transition-all cursor-pointer ${btnStyle}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              {/* Submission results row */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3 border-t border-[#222936]">
                <div>
                  {quizScore !== null ? (
                    <div className="flex items-center gap-2">
                      <Award className="h-5 w-5 text-[#fbbf24]" />
                      <span className="text-xs text-[#cbd5e1]">
                        Previous quiz score: <strong className="text-white font-mono">{quizScore}%</strong>
                      </span>
                    </div>
                  ) : (
                    <span className="text-xs text-[#8a99ad] font-mono">Complete selection to evaluate score.</span>
                  )}
                </div>

                {!quizSubmitted ? (
                  <button
                    id="btn-quiz-submit"
                    onClick={handleSubmitQuiz}
                    disabled={Object.keys(quizAnswers).length < currentLesson.quiz.length}
                    className="w-full sm:w-auto bg-[#10b981] hover:bg-[#059669] disabled:opacity-50 py-2 px-5 rounded-lg text-xs font-extrabold text-white transition-all font-mono tracking-wider cursor-pointer"
                  >
                    Submit Performance Checklist
                  </button>
                ) : (
                  <button
                    id="btn-quiz-retry"
                    onClick={() => {
                      setQuizSubmitted(false);
                      setQuizAnswers({});
                    }}
                    className="w-full sm:w-auto bg-[#1f2937] hover:bg-[#374151] border border-[#2e3748] py-2 px-5 rounded-lg text-[#cbd5e1] text-xs font-medium font-mono"
                  >
                    Reset Quiz Simulator
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

      </div>

      {/* SECTION 2: RHS Sidebar Syllabus Modules Checklist */}
      <div className="lg:col-span-4 space-y-6">
        
        {/* Completion analytics card */}
        <div className="bg-gradient-to-br from-[#111827] to-[#121b2f] border border-[#222936] rounded-2xl p-6 space-y-5 text-center">
          <h4 className="text-white text-xs font-bold uppercase tracking-wider font-mono text-[#8a99ad]">Syllabus Progress Ring</h4>
          
          <div className="relative inline-flex items-center justify-center">
            {/* Visual Arc Completion */}
            <svg className="w-32 h-32">
              <circle
                className="text-[#1f293d]"
                strokeWidth="8"
                stroke="currentColor"
                fill="transparent"
                r="50"
                cx="64"
                cy="64"
              />
              <circle
                className="text-[#4f46e5]"
                strokeWidth="8"
                strokeDasharray={2 * Math.PI * 50}
                strokeDashoffset={2 * Math.PI * 50 * (1 - courseCompletionRate / 100)}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
                r="50"
                cx="64"
                cy="64"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-3xl font-extrabold text-white font-mono">{courseCompletionRate}%</span>
              <span className="text-[9px] text-[#8a99ad] uppercase tracking-wider font-mono">COMPLETE</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 bg-[#0b0f19] rounded-lg border border-[#1f293d]">
              <span className="text-[#8a99ad] block text-[9px] uppercase font-mono">Course Syllabus</span>
              <span className="text-white font-bold">{totalLessons} Modules</span>
            </div>
            <div className="p-2.5 bg-[#0b0f19] rounded-lg border border-[#1f293d]">
              <span className="text-[#8a99ad] block text-[9px] uppercase font-mono">Completed</span>
              <span className="text-[#10b981] font-bold">{completedLessonsCount} Finished</span>
            </div>
          </div>
        </div>

        {/* Nested Syllabus directory checklists */}
        <div className="bg-[#111827] border border-[#222936] rounded-2xl p-5 space-y-4">
          <h4 className="text-white text-xs font-bold font-mono tracking-wider uppercase border-b border-[#222936] pb-2">
            Classroom Registry
          </h4>

          <div className="space-y-4">
            {currentCourse?.modules.map((mod) => (
              <div key={mod.id} className="space-y-2">
                <span className="text-[10px] text-[#fbbf24] font-mono tracking-wider block uppercase">
                  {mod.title}
                </span>

                <div className="space-y-1.5">
                  {mod.lessons.map((les) => {
                    const isLesCompleted = progressList.some(
                      (p) => p.courseId === currentCourse.id && p.lessonId === les.id && p.completed
                    );
                    const isLesActive = les.id === currentLesson?.id;

                    return (
                      <button
                        key={les.id}
                        onClick={() => setActiveLesson(les)}
                        className={`w-full text-left p-3 rounded-xl border text-xs flex items-center justify-between gap-3 transition-all cursor-pointer ${
                          isLesActive
                            ? "bg-[#1e293b] text-white border-[#3b82f6]"
                            : "bg-[#0b0f19] text-[#cbd5e1] border-[#1e293b] hover:bg-[#111827]"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {isLesCompleted ? (
                            <CheckCircle className="h-4 w-4 text-[#10b981] shrink-0" />
                          ) : (
                            <Circle className="h-4 w-4 text-[#475569] shrink-0" />
                          )}
                          <span className={`${isLesCompleted ? "line-through text-[#8a99ad]" : ""}`}>
                            {les.title}
                          </span>
                        </div>
                        <ChevronRight className="h-3.5 w-3.5 text-[#475569] shrink-0" />
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
