/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { X, Loader2, Lock, Mail, User, BookOpen, Layers } from "lucide-react";
import { UserSafe } from "../types";

interface AuthInterfaceProps {
  key?: string;
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (token: string, user: UserSafe) => void;
  initialMode?: "login" | "signup";
  initialBranch?: string;
  initialTrack?: string;
}

export default function AuthInterface({
  isOpen,
  onClose,
  onAuthSuccess,
  initialMode = "signup",
  initialBranch = "Electrical",
  initialTrack = "Fresher",
}: AuthInterfaceProps) {
  const [authMode, setAuthMode] = useState<"login" | "signup">(initialMode);
  const [name, setName] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [branch, setBranch] = useState<string>(initialBranch);
  const [track, setTrack] = useState<string>(initialTrack);
  
  // State for tracking login/signup feedback to user
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>("");

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setLoading(true);

    const endpoint = authMode === "signup" ? "/api/auth/signup" : "/api/auth/login";
    const payload = authMode === "signup"
      ? { name, email, password, branch, track }
      : { email, password };

    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Authentication failed. Clear your parameters or review validation requirements.");
      }

      // Store returned JWT token securely in localStorage
      localStorage.setItem("sixsigma_token", data.token);

      // Trigger success callback up to App parent component
      onAuthSuccess(data.token, data.user);
      onClose();
      
      // Reset local fields
      setName("");
      setEmail("");
      setPassword("");
    } catch (err: any) {
      setErrorMsg(err.message || "Network exception. Please assert connection properties are alive.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-955/80 backdrop-blur-sm">
      <div className="bg-[#1e293b] border border-[#334155] rounded-3xl w-full max-w-md p-6 relative space-y-4 shadow-2xl overflow-hidden">
        {/* Sky styling accent decorative blob */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#38bdf8]/10 rounded-full blur-[45px] pointer-events-none" />
        
        {/* Close trigger button */}
        <button
          id="btn-close-auth-panel"
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Header content */}
        <div className="space-y-1">
          <h4 className="text-xl font-extrabold text-white tracking-tight text-center uppercase font-mono">
            {authMode === "signup" ? "Create LMS Account" : "Access Moodle Portal"}
          </h4>
          <p className="text-xs text-slate-400 text-center font-mono leading-none">
            {authMode === "signup" ? "Enroll for credentials and sync course syllabus" : "Secure workspace access using encrypted JWT tokens"}
          </p>
        </div>

        {/* Authorization Form input cards */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          {errorMsg && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-400 font-mono leading-relaxed">
              ⚠️ {errorMsg}
            </div>
          )}

          {authMode === "signup" && (
            <div className="space-y-1">
              <label className="text-[10px] text-slate-400 font-mono uppercase font-bold tracking-wider flex items-center gap-1">
                <User className="h-3 w-3 text-sky-400" /> Full Name
              </label>
              <input
                id="auth-pane-name"
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="eg. Dr. Vikram Sarabhai"
                className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3.5 py-2 text-xs text-white outline-none focus:border-sky-400 transition-colors placeholder:text-slate-500 font-mono"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-mono uppercase font-bold tracking-wider flex items-center gap-1">
              <Mail className="h-3 w-3 text-sky-400" /> Email Address
            </label>
            <input
              id="auth-pane-email"
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@institution.com"
              className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3.5 py-2 text-xs text-white outline-none focus:border-sky-400 transition-colors placeholder:text-slate-500 font-mono"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-mono uppercase font-bold tracking-wider flex items-center gap-1">
              <Lock className="h-3 w-3 text-sky-400" /> Password Key
            </label>
            <input
              id="auth-pane-password"
              required
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3.5 py-2 text-xs text-white outline-none focus:border-sky-400 transition-colors placeholder:text-slate-500 font-mono"
            />
          </div>

          {authMode === "signup" && (
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 font-mono uppercase font-bold tracking-wider flex items-center gap-1">
                  <BookOpen className="h-3 w-3 text-sky-400" /> Engineering Module
                </label>
                <select
                  id="auth-pane-branch"
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="w-full bg-[#0f172a] border border-[#334155] text-white rounded-xl px-2 py-2 text-xs outline-none focus:border-sky-400 cursor-pointer font-mono"
                >
                  <option value="Electrical">Electrical (EE)</option>
                  <option value="Mechanical">Mechanical (ME)</option>
                  <option value="Civil">Civil (CE)</option>
                  <option value="Electronics">Electronics (EC)</option>
                  <option value="Computer">Computer (CS)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 font-mono uppercase font-bold tracking-wider flex items-center gap-1">
                  <Layers className="h-3 w-3 text-sky-400" /> Career Track
                </label>
                <select
                  id="auth-pane-track"
                  value={track}
                  onChange={(e) => setTrack(e.target.value)}
                  className="w-full bg-[#0f172a] border border-[#334155] text-white rounded-xl px-2 py-2 text-xs outline-none focus:border-sky-400 cursor-pointer font-mono"
                >
                  <option value="Fresher">🎓 Fresher Track</option>
                  <option value="Experienced">💼 Pro Track</option>
                  <option value="Manager">🧑‍💼 Lead Track</option>
                </select>
              </div>
            </div>
          )}

          <button
            id="btn-auth-panel-submit"
            type="submit"
            disabled={loading}
            className="w-full bg-[#0ea5e9] hover:bg-[#0284c7] py-2.5 rounded-xl text-xs font-bold text-white tracking-widest font-mono flex items-center justify-center gap-1.5 transition-all mt-4 cursor-pointer"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin text-white" />
            ) : authMode === "signup" ? (
              "Initialize PG Academy Session"
            ) : (
              "Authorize JWT Access"
            )}
          </button>
        </form>

        {/* Navigation toggles internally */}
        <div className="border-t border-[#334155] mt-2 pt-3 text-center">
          {authMode === "signup" ? (
            <p className="text-[10px] text-slate-400 font-mono">
              Already have credentials?{" "}
              <button
                type="button"
                onClick={() => {
                  setAuthMode("login");
                  setErrorMsg("");
                }}
                className="text-sky-400 hover:underline font-bold"
              >
                Log In Here
              </button>
            </p>
          ) : (
            <p className="text-[10px] text-slate-400 font-mono">
              Not yet registered?{" "}
              <button
                type="button"
                onClick={() => {
                  setAuthMode("signup");
                  setErrorMsg("");
                }}
                className="text-sky-400 hover:underline font-bold"
              >
                Enroll For Free
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
